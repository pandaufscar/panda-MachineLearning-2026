amigos = [
    {
        "nome": "Lucas",
        "idade": 21,
        "cidade": "São Paulo"
    },
    {
        "nome": "Bruno",
        "idade": 22,
        "cidade": "Curitiba"
    },
    {
        "nome": "Carla",
        "idade": 25,
        "cidade": "Campinas"
    }
]

print("Lista")
for i in amigos:
    print(f"Nome: {i['nome']} | Idade: {i['idade']} | Cidade: {i['cidade']}")