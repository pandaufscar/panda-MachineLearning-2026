aluno = {
    "nome": "Lucas",
    "idade": 21,
    "curso": "Ciência da Computação",
    "notas": [8.5, 8, 9]
}

media = sum(aluno["notas"]) / len(aluno["notas"])

print(f"Aluno: {aluno['nome']}")
print(f"Média: {media:.2f}")