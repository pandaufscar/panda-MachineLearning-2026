lista = ["Arroz", "Feijão", "Banana", "Bolacha", "Detergente"]
print(lista)
lista.append("Miojo")
print(f"\nLista atualizada: {lista}")
print(f"\nItem 2 da lista: {lista[2]}")